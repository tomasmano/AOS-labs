@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.example.org/NewWSDLFile/")
package simplefileserver.client;
